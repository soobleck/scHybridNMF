# Folders
- **real**: contains processed gene expression and cell location data as well as the names of selected genes. 
	- *seqFISH+*: The raw data for seqFISH+ can be obtained from the original authors at https://github.com/CaiGroup/seqFISH-PLUS.
	- *STARmap*: The raw data for STARmap can be obtained from the original authors at http://clarityresourcecenter.org.

- **simulated**: contains simulated raw gene expression, cell location, and cell label data. Additionally:
	- *strong_spatial_patterns*: Each gene expression data matrix is paired to its own unique cell location data matrix. 
	- *weak_spatial_patterns*: There are 10 cell location data matrices, and none are paired with a unique gene expression matrix.
